//
//  GPXAuthor.h
//  GPX Framework
//
//  Created by NextBusinessSystem on 12/04/06.
//  Copyright (c) 2012 NextBusinessSystem Co., Ltd. All rights reserved.
//

#import "GPXPerson.h"

@interface GPXAuthor : GPXPerson

@end
