//
//  GPXConst.h
//  GPX Framework
//
//  Created by NextBusinessSystem on 12/04/06.
//  Copyright (c) 2012 NextBusinessSystem Co., Ltd. All rights reserved.
//

extern NSString *const kGPXInvalidGPXFormatNotification;
extern NSString *const kGPXDescriptionKey;